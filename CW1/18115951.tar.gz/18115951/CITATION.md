
If you wish to refer to this course, please cite the following:
author: D�ith�
title: The Alchemist's Laboratory
version: 0.1.0
date released: 13.12.2018

Portions of the material are taken from [Software Carpentry](http://software-carpentry.org/)