
The Alchemist's Laboratory
==========

This is a package submitted as coursework for the Reasearch software in python module at UCL.

The package provides the final shelves of an alchemist's laboratory following an experiment. There is an otional parameter --reactions, which will produce only the number of reactions from the experiment. 
The package includes working unit tests.
The intial state of the shelves are found in alchemist.yml

Usage:
    
Use 'python setup.py install' to install the package. The final state can the be calculated by calling 'abracadabra alchemist.yml' from the command line, or 'abracadabra alchemist.yml --reactions' if you are only interested in finding the number of reations.